from selenium.webdriver.common.by import By
from pages.base_page import BasePage

class ProductsPage(BasePage):
    TITLE = (By.CLASS_NAME, "title")
    INVENTORY_ITEM = (By.CLASS_NAME, "inventory_item")
    ADD_TO_CART_BTN = (By.CSS_SELECTOR, "[id^='add-to-cart']")
    REMOVE_FROM_CART_BTN = (By.CSS_SELECTOR, "[id^='remove']")
    CART_BADGE = (By.CLASS_NAME, "shopping_cart_badge")
    BURGER_MENU = (By.ID, "react-burger-menu-btn")
    LOGOUT_LINK = (By.ID, "logout_sidebar_link")

    def is_on_products_page(self):
        return self.get_element_text(self.TITLE) == "Products"

    def get_product_count(self):
        return len(self.driver.find_elements(*self.INVENTORY_ITEM))

    def add_first_product_to_cart(self):
        self.wait_and_click(self.ADD_TO_CART_BTN)

    def remove_product_from_cart(self):
        self.wait_and_click(self.REMOVE_FROM_CART_BTN)

    def get_cart_count(self):
        try:
            return int(self.get_element_text(self.CART_BADGE))
        except:
            return 0

    def logout(self):
        self.wait_and_click(self.BURGER_MENU)
        self.wait_and_click(self.LOGOUT_LINK)
