import pytest
from selenium import webdriver

@pytest.fixture(scope="function")
def driver():
    # In 2025, Selenium handles drivers automatically
    driver = webdriver.Chrome() 
    driver.maximize_window()
    yield driver
    driver.quit()
