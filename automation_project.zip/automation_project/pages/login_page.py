from selenium.webdriver.common.by import By
from base_page import BasePage # Notice the change here

class LoginPage(BasePage):
    USERNAME_FIELD = (By.NAME, "username")
    PASSWORD_FIELD = (By.NAME, "password")
    LOGIN_BUTTON = (By.CSS_SELECTOR, "button[type='submit']")
    ERROR_MSG = (By.CSS_SELECTOR, ".oxd-alert-content-text")
    FORGOT_PASSWORD = (By.CSS_SELECTOR, ".orangehrm-login-forgot-header")

    def __init__(self, driver):
        super().__init__(driver)
        self.url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

    def open(self):
        self.driver.get(self.url)

    def login(self, username, password):
        if username: self.wait_and_send_keys(self.USERNAME_FIELD, username)
        if password: self.wait_and_send_keys(self.PASSWORD_FIELD, password)
        self.wait_and_click(self.LOGIN_BUTTON)