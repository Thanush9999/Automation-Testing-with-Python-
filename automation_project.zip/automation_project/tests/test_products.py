import pytest
from pages.login_page import LoginPage
from pages.products_page import ProductsPage

class TestProducts:
    @pytest.fixture(autouse=True)
    def login(self, driver):
        self.login_page = LoginPage(driver)
        self.products_page = ProductsPage(driver)
        self.login_page.open()
        self.login_page.login("standard_user", "secret_sauce")

    def test_products_display(self):
        assert self.products_page.get_product_count() == 6

    def test_add_to_cart(self):
        self.products_page.add_first_product_to_cart()
        assert self.products_page.get_cart_count() == 1

    def test_remove_from_cart(self):
        self.products_page.add_first_product_to_cart()
        self.products_page.remove_product_from_cart()
        assert self.products_page.get_cart_count() == 0

    def test_multiple_cart_items(self, driver):
        from selenium.webdriver.common.by import By
        btns = driver.find_elements(By.CSS_SELECTOR, "[id^='add-to-cart']")
        btns[0].click()
        btns[1].click()
        assert self.products_page.get_cart_count() == 2

    def test_navigation_to_details(self, driver):
        from selenium.webdriver.common.by import By
        driver.find_element(By.CLASS_NAME, "inventory_item_name").click()
        assert "inventory-item.html" in driver.current_url

    def test_logout(self, driver):
        self.products_page.logout()
        assert driver.current_url == "www.saucedemo.com"

    def test_product_sorting_existence(self, driver):
        from selenium.webdriver.common.by import By
        sort_dropdown = driver.find_element(By.CLASS_NAME, "product_sort_container")
        assert sort_dropdown.is_displayed()
