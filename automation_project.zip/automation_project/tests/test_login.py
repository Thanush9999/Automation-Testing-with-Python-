import pytest
from pages.login_page import LoginPage
from pages.products_page import ProductsPage

class TestLogin:
    @pytest.fixture(autouse=True)
    def setup(self, driver):
        self.login_page = LoginPage(driver)
        self.login_page.open()

    def test_successful_login(self, driver):
        self.login_page.login("standard_user", "secret_sauce")
        products = ProductsPage(driver)
        assert products.is_on_products_page()

    def test_invalid_username(self):
        self.login_page.login("wrong_user", "secret_sauce")
        assert "Username and password do not match" in self.login_page.get_error_message()

    def test_invalid_password(self):
        self.login_page.login("standard_user", "wrong_pass")
        assert "Username and password do not match" in self.login_page.get_error_message()

    def test_locked_user(self):
        self.login_page.login("locked_out_user", "secret_sauce")
        assert "this user has been locked out" in self.login_page.get_error_message()

    def test_empty_credentials(self):
        self.login_page.login("", "")
        assert "Username is required" in self.login_page.get_error_message()
